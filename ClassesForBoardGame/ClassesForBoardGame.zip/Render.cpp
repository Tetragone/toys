#include "Render.h"
#include <iostream>
#include <cstdio>

using namespace std;

Render::Render()
{
}


Render::~Render()
{
}