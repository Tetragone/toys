import 'package:flutter/material.dart';

class InformationSettingPage extends StatefulWidget{

  @override
  State createState() => InformationSettingPageState();
}

class InformationSettingPageState extends State<InformationSettingPage>{

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('information setting page'),
    );
  }
}