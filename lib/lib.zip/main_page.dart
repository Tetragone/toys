import 'package:flutter/material.dart';

class MainPage extends StatefulWidget{

  @override
  State createState() => MainPageState();
}

class MainPageState extends State<MainPage>{
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text('main page'),
    );
  }
}